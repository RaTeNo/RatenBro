<?php get_header(); ?>

                        <?php dimox_breadcrumbs(); ?>
                                          
                        <h1>404</h1>                 
                        
                        <div class="article-body text_block">
                            <p>Можете найти необходимую информацию, воспользовавшись поиском или картой сайта</p>
                        </div>
                        <?php  get_template_part( 'template-parts/related', 'posts' ); ?>


                    </div>


                </div>
            </div>



<?php get_footer(); ?>
