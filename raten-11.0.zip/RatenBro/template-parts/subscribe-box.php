<?php

?>

<div class="b-subscribe">
    <div class="b-subscribe__i">
        <div class="b-subscribe__header">
            Получай лучшие статьи на почту каждую неделю
        </div>

        <div class="b-subscribe__form">

            <form action="" method="POST" target="_blank">
                <input name="est-email" type="text" placeholder="Введите e-mail" required>
                <button>Подписаться</button>
            </form>

        </div>
    </div>
</div>