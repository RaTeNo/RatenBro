
                    
                        <div class="articles-content">
                            <h1 class="article-main__title"><?php the_title(); ?></h1>

                        </div>                       

                        <div class="article-body text_block">
                            <?php the_content(); ?>                           
                        </div>
