<form role="search"  method="get" id="searchform" action="<?php echo home_url( '/' ) ?>" >
    <div class="search-block mobile--none">
        <input type="text" name="s" placeholder="Поиск по блогу:">
        <button></button>
    </div>
</form>