<?php

/*
 * Package-Name: Julianus, a tribute to Julien
 * Package-URI: http://www.ikiru.ch/blog/?p=189
 * Package-Description: A Wordpress smilies packages.
 * Package-Author: Psykotik
 * Package-Author-URI: http://www.ikiru.ch/
 */

$wp_smilies = array(
	':p'        => '20x20-adore.png',
  ':-p'        => '20x20-after_boom.png',  
	'8)'        => '20x20-ah.png',
  '8-)'        => '20x20-amazed.png', 
	':lol:'      => '20x20-bad_smelly.png',
	'=('        => '20x20-beat_brick.png',
  ':('        => '20x20-beat_plaster.png',
  ':-('        => '20x20-beated.png',
	':8'        => '20x20-beauty.png',
	';)'        => '20x20-big_smile.png',
  ';-)'        => '20x20-boss.png', 
	':(('       => '20x20-byebye.png',
	':o:'       => '20x20-canny.png',
    
  
	);

?>
