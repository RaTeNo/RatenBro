
    </main>


    <?php get_template_part( 'template-parts/layout/footer' ) ?>	
    <?php wp_footer(); ?>    
     <?php echo raten_get_option( 'code_body' ) ?>

</body>
</html>



	